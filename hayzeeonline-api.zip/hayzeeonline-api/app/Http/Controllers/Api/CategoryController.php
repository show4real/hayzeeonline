<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\Models\Category;
use App\Http\Requests\CategoryRequest;
use App\Http\Traits\productTrait;
use Illuminate\Support\Facades\URL;

class CategoryController extends Controller
{
    use productTrait;

    public function index(Request $request)
    {
        $categories = Category::search($request->search)
            ->latest()
            ->paginate($request->rows, ['*'], 'page', $request->page);
        return response()->json(compact('categories'));
    }



    public function createSlug($title)
    {
        $slug = Str::slug($title);
        return $slug . '-' . time();
    }


    public function create(CategoryRequest $request)
    {
        $data = $request->validated();

        $image = $request->image;
        $imageName = time() . '.' . $image->getClientOriginalExtension();
        $imageUrl = URL::asset('images/' . $imageName);


        $category = Category::create([
            'name' => $data['name'],
            'slug' => Str::slug($data['name']),
            'image_url' => $imageUrl,
            'created_at' => now(),
            'updated_at' => now()
        ]);

        $this->singleUpload($image, $imageName, 0);



        return $category;
    }


    public function update(CategoryRequest $request, Category $category)
    {
        $this->deleteImage($category->image_url);

        $data = $request->validated();

        $image = $request->file('image');
        $rotations = $request->rotations;
        $imageName = time() . '.' . $image->getClientOriginalExtension();
        $imageUrl = URL::asset('images/' . $imageName);



        $category->update([
            'name' => $data['name'],
            'image_url' => $imageUrl,
            'slug' => Str::slug($data['name']),
        ]);



        $this->singleUpload($image, $imageName, 0);

        return response()->json(compact('category'));
    }



    public function delete($id)
    {
        $category = Category::find($id);

        if ($category) {
            $this->deleteImage($category->image_url);
            $category->delete();
            return response()->json(true);
        }
        return response()->json(['message' => 'Category not found'], 404);
    }

    public function userCategories(Request $request)
    {
        $categories = Category::has('products')->with('products')->latest()->get();


        return response()->json(compact('categories'));
    }
}
