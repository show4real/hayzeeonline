<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\Brand;
use App\Models\Category;


class ShopController extends Controller
{

    public function trending(Request $request)
    {

        $products = Product::get();

        return response()->json(compact('products'));
    }

    public function products(Request $request)
    {

        $products = Product::search($request->search)
            ->brand($request->brand)
            ->category($request->category)
            ->sort($request->sort)
            ->filterByPrice($request->price[0], $request->price[1])
            ->latest()
            ->paginate($request->rows, ['*'], 'page', $request->page);

        return response()->json(compact('products'));
    }

    public function categoryProducts(Request $request)
    {


        $products = Product::search($request->search)
            ->brand($request->brand)
            ->catProduct($request->categoryslug)
            ->brandProduct($request->brandSlug)
            ->sort($request->sorting)
            ->storage($request->storages)
            ->processor($request->processors)
            ->ram($request->rams)
            ->filterByPrice($request->price[0], $request->price[1])
            ->latest()
            ->paginate($request->rows, ['*'], 'page', $request->page);

        return response()->json(compact('products'));
    }

    public function show($slug)
    {
        $product = Product::where('slug', $slug)->first();
        return response()->json(compact('product'));
    }

    public function brands()
    {
        $brands = Brand::get();
        return response()->json(compact('brands'));
    }
}